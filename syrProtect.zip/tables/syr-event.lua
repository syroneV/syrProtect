AnticheatConfig = AnticheatConfig or {}

AnticheatConfig.BlacklistedEventsAntiESX = { -- Trigger Blacklist (Ajouter vous meme si vous voulez)
    "gcPhone:_internalAddMessage",
}