Anticheat = Anticheat or {}
Anticheat.Endpoints = {
    ["GetTextureResolution"] = true,
	["SetPedInfiniteAmmo"] = true,
	["ShootSingleBulletBetweenCoords"] = true,
	["ShootSingleBulletBetweenCoordsIgnoreEntity"] = true,
	["ShootSingleBulletBetweenCoordsIgnoreEntityNew"] = true,
	["SetSuperJumpThisFrame"] = true,
	["SetExplosiveMeleeThisFrame"] = true,
	["SetExplosiveAmmoThisFrame"] = true,
	["SetPedShootsAtCoord"] = true,
	["SetHandlingField"] = true,
	["SetHandlingInt"] = true,
	["SetHandlingFloat"] = true,
	["SetHandlingVector"] = true,
	["AddExplosion"] = true,
	["NetworkExplodeVehicle"] = true,
	["ShowHeadingIndicatorOnBlip"] = true,
	["SetBlipNameToPlayerName"] = true,
	["SetBlipCategory"] = true,
	["ApplyForceToEntity"] = true,
	["LoadResourceFile"] = true,
	["SetEntityRotation"] = true,
	["StartShapeTestRay"] = true,
	["SetPedAlertness"] = true,
	["DrawLine"] = true,
	["ResetPlayerStamina"] = Anticheat.AntiStamina,
	["GetPedBoneCoords"] = true,
	
}

Anticheat.GlobalEndpoints = {
	["KeyboardInput"] = true,
	["GetKeyboardInput"] = true,
	["_Executor"] = true,
	["_Executor_Strings"] = true,
}