Anticheat = Anticheat or {}
Anticheat.WhitelistedProps = {
	"prop_ballistic_shield",
	"prop_amb_phone",
	"xm_prop_x17_tem_control_01",
	"player_zero",
	"prop_bowling_ball",
	"p_parachute1_mp_s"
}