Anticheat = Anticheat or {}
Anticheat.BlacklistExposion = {
	0,
	1,
	2,
	3,
	4,
	5,
	7,
	9,
	12,
	25,
	31,
	32,
	33,
	35,
	36,
	37,
	38
}