local AnticheatName = "syrDefence 2.0"
PrintConsole("Version: "..AnticheatName)