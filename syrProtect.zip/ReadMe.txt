Disable all your external ban systems.
Don't rename this script.
Rename all your TriggerServerEvent by Rsv and do in each fxmanifest: Insert in your client_scripts first "@syrProtect/config.lua" and "@syrProtect/client/cl_anticheat.lua"
Change all your trigger "esx" by other things
Replace function SetEntityHealth by Anticheat:SetPedHealth 
Replace function SetPedArmour by Anticheat:SetEntityArmour
This Anticheat use a screenshot-basic (obligatoire)


ensure syrProtect


ADMIN BYPASS:
add_ace syrProtect allow 
add_ace identifier.license:000000000000000000000 syrProtect allow
