Config = {
    Debug = true,
    Notification = true, -- true == Notification Normal, false == AdvancedNotification
    Menu = {
        Font = 4,
        ButtonFont = 0,
        Opacity = 255,
        Scaleform = true,
        Submenu = false, -- Voir le submenu
        HeaderScaleForm = "MP_MENU_GLARE",
        HauteurMenu = .0800, --Rageui = 0.800 et pmenu environ 0600
        Rouge = 255,
        Bleu = 100,
        Vert = 0,
    },
}